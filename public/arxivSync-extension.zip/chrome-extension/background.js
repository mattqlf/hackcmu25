chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.sync.set({ autoRedirect: true }, function() {
    console.log('ArXiv Redirector extension installed with auto-redirect enabled');
  });
});