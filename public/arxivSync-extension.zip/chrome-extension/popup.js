document.addEventListener('DOMContentLoaded', async function() {
  const toggle = document.getElementById('autoRedirectToggle');
  const status = document.getElementById('status');

  try {
    const result = await chrome.storage.sync.get(['autoRedirect']);
    const autoRedirect = result.autoRedirect !== false;

    toggle.checked = autoRedirect;
    updateStatus(autoRedirect);
  } catch (error) {
    console.error('Error loading settings:', error);
    status.textContent = 'Error loading settings';
  }

  toggle.addEventListener('change', async function() {
    const isEnabled = toggle.checked;

    try {
      await chrome.storage.sync.set({ autoRedirect: isEnabled });
      updateStatus(isEnabled);

      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && tab.url.includes('arxiv.org/abs/')) {
        chrome.tabs.reload(tab.id);
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      status.textContent = 'Error saving settings';
    }
  });

  function updateStatus(isEnabled) {
    status.className = 'status ' + (isEnabled ? 'enabled' : 'disabled');
    if (isEnabled) {
      status.textContent = 'Auto redirect enabled';
    } else {
      status.textContent = 'Manual redirect only';
    }
  }
});