(async function() {
  const currentUrl = window.location.href;
  const arxivMatch = currentUrl.match(/https:\/\/arxiv\.org\/(abs|pdf|html)\/(.+)/);

  if (!arxivMatch) return;

  const arxivId = arxivMatch[2];
  const arxivsyncUrl = `https://arxivsync.vercel.app/paper/${arxivId}`;

  const result = await chrome.storage.sync.get(['autoRedirect']);
  const autoRedirect = result.autoRedirect !== false;

  if (autoRedirect) {
    window.location.href = arxivsyncUrl;
  } else {
    // Wait for DOM to be ready, then create button immediately
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => createRedirectButton(arxivsyncUrl));
    } else {
      createRedirectButton(arxivsyncUrl);
    }
  }

  function createRedirectButton(url) {
    if (document.getElementById('hackcmu-redirect-btn')) return;

    // Wait for body to be available
    function addButton() {
      if (!document.body) {
        setTimeout(addButton, 10);
        return;
      }

      const button = document.createElement('button');
      button.id = 'hackcmu-redirect-btn';
      button.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M7 7h10v10"/>
            <path d="M7 17 17 7"/>
          </svg>
          <span style="font-weight: 500;">Open in arXivSync</span>
        </div>
      `;

      button.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        padding: 12px 16px;
        background: rgba(255, 255, 255, 0.95);
        color: #0f172a;
        border: 1px solid rgba(226, 232, 240, 0.8);
        border-radius: 8px;
        cursor: pointer;
        font-size: 14px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06);
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transform: translateY(-10px);
        backdrop-filter: blur(8px);
      `;

      button.addEventListener('mouseenter', () => {
        button.style.transform = 'translateY(-2px)';
        button.style.boxShadow = '0 4px 12px rgba(0,0,0,0.12), 0 2px 4px rgba(0,0,0,0.08)';
        button.style.borderColor = 'rgba(226, 232, 240, 1)';
      });

      button.addEventListener('mouseleave', () => {
        button.style.transform = 'translateY(0)';
        button.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06)';
        button.style.borderColor = 'rgba(226, 232, 240, 0.8)';
      });

      button.addEventListener('click', () => {
        window.location.href = url;
      });

      document.body.appendChild(button);

      // Animate in
      setTimeout(() => {
        button.style.opacity = '1';
        button.style.transform = 'translateY(0)';
      }, 50);
    }

    addButton();
  }

  // Also handle navigation events for single-page app behavior
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      // Remove existing button if URL changed
      const existingButton = document.getElementById('hackcmu-redirect-btn');
      if (existingButton) {
        existingButton.remove();
      }

      // Check if new URL matches and create button
      const newMatch = url.match(/https:\/\/arxiv\.org\/(abs|pdf|html)\/(.+)/);
      if (newMatch && !autoRedirect) {
        const newArxivId = newMatch[2];
        const newHackcmuUrl = `https://hackcmu25.vercel.app/paper/${newArxivId}`;
        createRedirectButton(newHackcmuUrl);
      }
    }
  }).observe(document, { subtree: true, childList: true });
})();